import { lazy, type ComponentType } from 'react';
import {
  ColorsPage,
  FontsPage,
  LayoutPage,
  OverviewPage,
} from './foundations';

function lazyPage(load: () => Promise<ComponentType>) {
  return lazy(async () => ({ default: await load() }));
}

const FesOsDemo = lazyPage(() =>
  import('./demos/fes-os').then(({ FesOsDemo }) => FesOsDemo),
);
const GuidelinesDemo = lazyPage(() =>
  import('./demos/guidelines').then(({ GuidelinesDemo }) => GuidelinesDemo),
);
const AccessibilityPage = lazyPage(() =>
  import('./accessibility').then(({ AccessibilityPage }) => AccessibilityPage),
);

export type PreviewEntry = {
  id: string;
  name: string;
  description: string;
  Page: ComponentType;
};

export type NavGroup = {
  name: string;
  entries: PreviewEntry[];
};

export const DESIGN_SYSTEM = {
  title: 'Fes OS Design System',
  description:
    'Foundations, components, and responsive interaction patterns for the Fes Naqvi desktop portfolio in light and dark themes.',
} as const;

export const OVERVIEW_ENTRY: PreviewEntry = {
  id: 'overview',
  name: 'Overview',
  description: 'The visual foundations and principles that shape Fes OS.',
  Page: OverviewPage,
};

export const NAV_GROUPS: NavGroup[] = [
  {
    name: 'Foundations',
    entries: [
      {
        id: 'color-roles',
        name: 'Color roles',
        description: 'Complete semantic palettes for light and dark themes.',
        Page: ColorsPage,
      },
      {
        id: 'type-scale',
        name: 'Typography',
        description: 'Space Grotesk and DM Mono roles and hierarchy.',
        Page: FontsPage,
      },
      {
        id: 'spacing-radius',
        name: 'Spacing & radius',
        description: 'The four-pixel spacing rhythm and corner treatments.',
        Page: LayoutPage,
      },
      {
        id: 'icon-motion',
        name: 'Iconography & motion',
        description: 'Keyline icon rules, transition timing, and interaction feedback.',
        Page: GuidelinesDemo,
      },
      {
        id: 'accessibility',
        name: 'Accessibility',
        description: 'WCAG AA targets and the accessibility rules followed by the portfolio.',
        Page: AccessibilityPage,
      },
    ],
  },
  {
    name: 'Components',
    entries: [
      {
        id: 'fes-os-pilot',
        name: 'Portfolio primitives',
        description: 'Actions, labels, status, surfaces, and project cards used by the portfolio.',
        Page: FesOsDemo,
      },
    ],
  },
  {
    name: 'Patterns',
    entries: [
      {
        id: 'responsive-workspace',
        name: 'Responsive workspace',
        description: 'Freeform desktop, managed mobile, and preserved geometry.',
        Page: GuidelinesDemo,
      },
    ],
  },
];

export const ALL_ENTRIES = [
  OVERVIEW_ENTRY,
  ...NAV_GROUPS.flatMap((group) => group.entries),
];